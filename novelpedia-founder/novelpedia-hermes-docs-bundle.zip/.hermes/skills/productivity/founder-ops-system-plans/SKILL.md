---
name: founder-ops-system-plans
description: Plan founder-ops operating systems for daily triage, standups, blocker escalation, decision capture, and founder briefs using a canonical execution layer.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [planning, founder-ops, operations, standups, triage, reporting]
---

# Founder Ops System Plans

## When to use

Use this when a user wants an implementation plan for a founder-ops operating system, especially around:
- daily triage
- standups
- blocker escalation
- decision logging
- founder briefing
- execution visibility across Discord, docs, meetings, and growth dashboards

## Goal

Produce a practical system plan that turns fragmented operating context into one canonical execution layer plus concrete daily operating flows.

## Required workflow

1. Load the `writing-plans` skill first.
2. Read all provided onboarding, operating-profile, and suggestion documents.
3. Extract the operating pain points, existing tools, key channels, metrics, escalation preferences, and privacy constraints.
4. Design around one canonical operating layer:
   - structured state in a master sheet
   - narrative memory in markdown docs
   - raw sources remain evidence, not final truth
5. Include a source-of-truth map that says:
   - what the raw source is
   - what canonical artifact stores normalized truth
   - who owns the input
   - what Hermes does
   - what the founder sees
6. Define the core data model:
   - people
   - action items
   - daily standups
   - blockers
   - decisions
   - growth snapshot
   - nudges log
   - alerts log
   - founder brief index
   - meeting memory index
7. Specify the operating cadence with timestamps or a default daily rhythm:
   - pre-scan
   - standup reminder
   - standup deadline
   - missing standup follow-up
   - triage finalize
   - midday blocker sweep
   - follow-up sweep
   - founder brief generation
   - urgent event triggers
8. Be concrete about inputs:
   - who provides them
   - when they are provided
   - where they are submitted or discovered
   - where Hermes stores them
   - what gets surfaced to the founder
   - what is logged for history
9. Include folder and file structure for Drive/docs and the canonical sheet tabs.
10. Include markdown templates for at least:
   - daily standup capture
   - decision log entry
   - founder brief
   - employee profile
   - blocker report
11. Include a phased roadmap ordered by leverage and realism.
12. End with blunt failure modes and success metrics.
13. Write the plan to the requested markdown path and verify the file contents with `read_file`.

## Planning principles

- Build for execution pressure, not passive note-taking.
- Prefer adoption over elegance at v1.
- Do not assume perfect integrations; manual or semi-manual first is often correct.
- Force owner, status, blocker, next action, due date/urgency, and provenance.
- Keep the founder brief exception-first.
- Treat privacy and employee-profile governance seriously.

## Common pitfalls

1. Making Discord or memory the real source of truth.
2. Writing vague workflows without concrete timing or storage locations.
3. Producing founder briefs that paraphrase everything instead of surfacing blockers, growth movement, and urgent risks.
4. Forgetting to define escalation thresholds.
5. Adding employee-profile or multi-agent concepts before the execution layer is stable.
6. Treating metrics with false precision when sources are inconsistent.

## Verification checklist

Before finalizing, confirm the plan includes:
- architecture
- operating flows
- data model
- source-of-truth mapping
- doc/sheet/file structure
- cron/reminder design
- escalation rules
- founder report format
- required markdown templates
- rollout phases
- risks/failure modes

## Output style

- blunt
- concrete
- system-first
- no generic management filler

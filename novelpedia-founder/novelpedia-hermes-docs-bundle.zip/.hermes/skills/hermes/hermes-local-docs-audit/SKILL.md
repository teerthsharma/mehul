---
name: hermes-local-docs-audit
description: Audit whether Hermes documentation is installed locally, verify useful local doc roots, and create a concise local lookup index or fallback cache.
version: 1.0.1
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [hermes, docs, audit, local-cache, references]
---

# Hermes local docs audit

Use this when a task asks whether Hermes docs are available locally, where the best local docs live, or to build a quick local reference/cache under `~/.hermes/references/hermes-docs/`.

## Trigger conditions
- User asks whether Hermes docs are installed locally.
- You need fast local lookup paths for Hermes docs.
- You need to decide whether to scrape/cache Hermes docs pages locally.

## Procedure
1. Load the `hermes-agent` skill first for the expected repo/doc layout.
2. Check the likely local paths explicitly:
   - `~/.hermes/hermes-agent/website/docs`
   - `~/.hermes/hermes-agent/docs`
   - `~/.hermes/hermes-agent/README.md`
   - the repo's development-guide file in the repo root, if present
3. Use `terminal` for existence checks if file search is flaky. A reliable shell snippet is:
   ```bash
   for p in "$HOME/.hermes/hermes-agent" \
            "$HOME/.hermes/hermes-agent/website/docs" \
            "$HOME/.hermes/hermes-agent/docs" \
            "$HOME/.hermes/hermes-agent/README.md"; do
     if [ -e "$p" ]; then
       [ -d "$p" ] && t=dir || t=file
       printf '%s\t%s\n' "$t" "$p"
     else
       printf 'missing\t%s\n' "$p"
     fi
   done
   ```
4. If docs roots exist, inventory them with `python` + `Path.rglob()` from `terminal` to count Markdown files and list representative paths.
5. Verify by actually reading representative files with `read_file` (do not just rely on existence):
   - `README.md`
   - `website/docs/index.md`
   - one or more core docs such as quickstart, configuration, messaging, reference, providers, architecture
   - if `docs/` exists, read one file there too (for example `docs/acp-setup.md`)
6. If docs are present:
   - Write an audit report under `~/.hermes/onboarding/.../local-hermes-docs-audit.md` if requested.
   - Create `~/.hermes/references/hermes-docs/index.md` with:
     - primary docs root
     - high-signal files
     - note that `website/docs` is canonical and `docs/` is supplementary
     - whether extra scraping is unnecessary
7. If docs are missing:
   - Create `~/.hermes/references/hermes-docs/`
   - Fetch key pages from `https://hermes-agent.nousresearch.com/docs/` into local markdown/html copies (use available web tooling or `curl` if needed)
   - Include at minimum: landing page, quickstart, configuration, CLI commands, slash commands, tools reference, providers, messaging, architecture
   - Write an `index.md` describing the cached files and source URLs
8. Verify the report/index after writing by reading them back with `read_file`.

## Recommended index contents
- Status: docs installed or cached
- Absolute primary root path
- High-signal entry points:
  - `website/docs/index.md`
  - `getting-started/quickstart.md`
  - `user-guide/configuration.md`
  - `user-guide/messaging/index.md`
  - `reference/cli-commands.md`
  - `reference/slash-commands.md`
  - `reference/tools-reference.md`
  - `reference/environment-variables.md`
  - `integrations/providers.md`
  - `developer-guide/architecture.md`
  - `README.md`
- Clear note on whether scraping/cache installation is still needed

## Pitfalls
- `search_files(target='files')` may not reliably surface these paths when using `~` or exact filename globs in some environments. If results are unexpectedly empty, fall back to `terminal` existence checks and `python`/`Path.rglob()` for inventory.
- The repo `docs/` directory is not necessarily the canonical website docs. Prefer `website/docs` as the primary local reference root when it exists.
- Do not conclude docs are installed based only on directory existence; read representative files to verify usable content.

## Verification checklist
- Confirm whether docs are installed locally: yes/no.
- Provide exact useful paths.
- State whether extra scraping/cache work is needed now.
- Ensure the requested report and index files exist and contain concrete paths.

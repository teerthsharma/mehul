# Novelpedia / Hermes Hallucination Audit

Date: 2026-04-16

## Scope audited
- `~/.hermes/onboarding/novelpedia-founder/employee-agent-guidelines.md`
- `~/.hermes/onboarding/novelpedia-founder/employee-agent-skill-blueprints.md`
- `~/.hermes/onboarding/novelpedia-founder/team-onboarding/system-overview.md`
- `~/.hermes/onboarding/novelpedia-founder/team-onboarding/employee-soul-template.md`
- `~/.hermes/onboarding/novelpedia-founder/team-onboarding/employee-agents-template.md`
- `~/.hermes/onboarding/novelpedia-founder/daily-triage-system-implementation-plan.md`

## Hermes references checked
Primary docs requested:
- `~/.hermes/hermes-agent/website/docs/guides/use-soul-with-hermes.md`
- `~/.hermes/hermes-agent/website/docs/user-guide/profiles.md`
- `~/.hermes/hermes-agent/website/docs/user-guide/features/memory.md`
- `~/.hermes/hermes-agent/website/docs/user-guide/features/memory-providers.md`
- `~/.hermes/hermes-agent/website/docs/reference/profile-commands.md`
- `~/.hermes/hermes-agent/AGENTS.md`

Additional local docs used where the primary list was not enough to verify AGENTS/context behavior:
- `~/.hermes/hermes-agent/website/docs/user-guide/features/context-files.md`
- `~/.hermes/hermes-agent/website/docs/user-guide/configuration.md`
- `~/.hermes/hermes-agent/website/docs/reference/faq.md`

Onboarding context checked:
- `~/.hermes/onboarding/novelpedia-founder/assistant-suggestions.md`
- `~/.hermes/onboarding/novelpedia-founder/assistant-extra-questions.md`

## Overall result
Most of the planning docs were directionally sound and did not contain major Hermes hallucinations. I found two material Hermes-specific inaccuracies / omissions and patched them directly.

## Findings and fixes

### 1. Draft files vs real runtime files were blurred
Issue:
- The onboarding docs risked implying that `SOUL.draft.md`, `AGENTS.draft.md`, or a “profile-local AGENTS” file would behave like actual Hermes runtime files.

Verified Hermes behavior:
- `SOUL.md` is loaded from the active profile's `HERMES_HOME`.
- `AGENTS.md` is working-directory context, not a profile-home twin of `SOUL.md`.
- In messaging flows, the loaded `AGENTS.md` depends on the working directory / `MESSAGING_CWD`.
- Hermes does not automatically load `SOUL.draft.md` or `AGENTS.draft.md`.

Patched:
- `team-onboarding/system-overview.md`
- `team-onboarding/employee-soul-template.md`
- `team-onboarding/employee-agents-template.md`
- `employee-agent-guidelines.md`

### 2. Multi-profile live messaging token constraints were missing
Issue:
- The docs recommended one profile per employee, but did not note that simultaneous live profile gateways cannot share a single Discord/Telegram/Slack bot token.

Verified Hermes behavior:
- Profiles are isolated.
- Each live gateway profile needs its own token/process.
- Hermes token locks block multiple active profiles from sharing one messaging token.

Patched:
- `employee-agent-guidelines.md`
- `team-onboarding/system-overview.md`
- `daily-triage-system-implementation-plan.md`

## Checks that passed
No correction was needed for these points:
- Profile isolation claims were supported by Hermes profile docs.
- Memory claims about bounded built-in memory, frozen session-start injection, and external providers being additive were supported.
- SOUL-vs-AGENTS separation was correct in spirit and is now clearer in runtime terms.
- Privacy/reporting guidance was mostly policy design guidance grounded in the onboarding context, not false claims about Hermes.
- `employee-agent-skill-blueprints.md` read as a draft design catalog rather than a set of false claims about installed Hermes behavior.

## Files modified during audit
- `~/.hermes/onboarding/novelpedia-founder/employee-agent-guidelines.md`
- `~/.hermes/onboarding/novelpedia-founder/team-onboarding/system-overview.md`
- `~/.hermes/onboarding/novelpedia-founder/team-onboarding/employee-soul-template.md`
- `~/.hermes/onboarding/novelpedia-founder/team-onboarding/employee-agents-template.md`
- `~/.hermes/onboarding/novelpedia-founder/daily-triage-system-implementation-plan.md`

## Follow-up note
If Novelpedia truly wants one Hermes profile per employee plus live Discord DMs, it should plan either:
- one bot token/process per employee profile, or
- a separate routing layer on top of Hermes profiles.

That is the main operational constraint the original drafts were missing.

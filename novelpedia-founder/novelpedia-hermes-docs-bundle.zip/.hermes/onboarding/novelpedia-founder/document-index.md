# Novelpedia Hermes Document Index

## Core onboarding and operating docs
- ~/.hermes/onboarding/novelpedia-founder/assistant-suggestions.md
- ~/.hermes/onboarding/novelpedia-founder/assistant-extra-questions.md
- ~/.hermes/onboarding/novelpedia-founder/assistant-operating-profile-draft.md
- ~/.hermes/onboarding/novelpedia-founder/My Personal AI Assistant Operating System.md
- ~/.hermes/onboarding/novelpedia-founder/start-integration-prompt.md

## System plans
- ~/.hermes/onboarding/novelpedia-founder/daily-triage-system-implementation-plan.md
- ~/.hermes/onboarding/novelpedia-founder/employee-agent-guidelines.md
- ~/.hermes/onboarding/novelpedia-founder/employee-agent-skill-blueprints.md

## Team onboarding package
- ~/.hermes/onboarding/novelpedia-founder/team-onboarding/system-overview.md
- ~/.hermes/onboarding/novelpedia-founder/team-onboarding/welcome-dm-script.md
- ~/.hermes/onboarding/novelpedia-founder/team-onboarding/employee-questionnaire.md
- ~/.hermes/onboarding/novelpedia-founder/team-onboarding/employee-profile-template.md
- ~/.hermes/onboarding/novelpedia-founder/team-onboarding/employee-soul-template.md
- ~/.hermes/onboarding/novelpedia-founder/team-onboarding/employee-agents-template.md
- ~/.hermes/onboarding/novelpedia-founder/team-onboarding/team-dm-announcement.md

## Audit and verification docs
- ~/.hermes/onboarding/novelpedia-founder/hallucination-audit.md
- ~/.hermes/onboarding/novelpedia-founder/local-hermes-docs-audit.md
- ~/.hermes/references/hermes-docs/index.md

## Reusable skills created during planning/audit
- ~/.hermes/skills/productivity/founder-ops-system-plans/SKILL.md
- ~/.hermes/skills/hermes/hermes-local-docs-audit/SKILL.md

## Notes
- Correct Discord announcement was posted to channel ID 1375477971627937834 with an @everyone ping.
- Local Hermes docs are installed under ~/.hermes/hermes-agent/website/docs.
- The hallucination audit found 2 real Hermes-specific corrections and patched the affected docs.

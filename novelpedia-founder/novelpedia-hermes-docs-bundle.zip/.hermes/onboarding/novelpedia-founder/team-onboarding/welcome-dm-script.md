# Novelpedia Employee Onboarding Welcome DM Script

Hey — I’m Hermes, Novelpedia’s work assistant.

I’m here to help with execution: prioritizing, clarifying tasks, identifying blockers, drafting follow-ups, summarizing status, and helping you move work forward faster.

I’m going to ask a short set of questions so I can build your profile and personalize how I help.

Important boundaries:
- this is for work help, not therapy
- do not send passwords, tokens, API keys, credentials, or sensitive secrets
- keep answers short and practical
- we can refine your profile over time

Let’s start.

1. What should I call you?
2. What is your Discord username in this server?
3. What is your role at Novelpedia?
4. What are the main things you own right now?
5. What are the top 1-3 things you’re working on right now?
6. What usually blocks you or slows you down?
7. Who do you most often depend on to move faster?
8. What kind of help from me would be most useful: prioritizing, brainstorming, reminders, follow-up drafting, breaking work down, or pressure/check-ins?
9. Do you want me to be blunt, neutral, or more supportive by default?
10. What kinds of updates are fine for manager/founder visibility, and what should stay private unless you explicitly want it shared?
11. What is the most important thing you need to get done next?
12. What is the biggest blocker or risk I should know about today?

Once you answer, I’ll turn this into:
- a clean work profile
- personalized help style
- a first-pass memory of your role and current work
- better follow-up support going forward

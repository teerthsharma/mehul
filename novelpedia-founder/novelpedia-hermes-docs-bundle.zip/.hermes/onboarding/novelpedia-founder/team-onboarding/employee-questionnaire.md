# Novelpedia Employee Onboarding Questionnaire

Use this when onboarding a team member via Discord DM.

## Short version
1. What should I call you?
2. What is your Discord username in this server?
3. What is your role?
4. What do you mainly own or handle?
5. What are the top 1-3 things you are working on right now?
6. What usually blocks or slows you down?
7. Who do you most often depend on?
8. What kind of help from me is most useful?
9. Do you want me blunt, neutral, or more supportive?
10. What can be manager-visible by default, and what should stay private unless you ask otherwise?
11. What do you need to get done next?
12. What is the biggest risk or blocker today?

## Why each question exists
1-4: identity, role, and durable ownership
5-7: current execution context and dependency map
8-9: personalization and SOUL drafting
10: privacy/reporting boundary
11-12: immediate usefulness

## Do not ask unless clearly useful later
- personal-life questions
- open-ended therapy questions
- abstract personality tests
- broad “tell me about yourself” prompts
- anything that pressures them to share secrets or confidential information

## Follow-up prompts if answers are vague
If role is vague:
- What kind of output are you personally responsible for?

If current work is vague:
- What are the actual deliverables on your plate this week?

If blockers are vague:
- What specifically makes the work stall: waiting on people, unclear requirements, too much scope, missing assets, or something else?

If help style is vague:
- Should I mostly help by clarifying work, nudging you, drafting messages, or helping you think through problems?

If privacy boundary is vague:
- Is it okay if I summarize blockers and task status upward, while keeping rough brainstorming/private reflection private unless you explicitly ask me to share it?

## Completion criteria
An onboarding is good enough when Hermes can answer:
- who is this person?
- what do they own?
- what are they working on now?
- what blocks them?
- how should Hermes help them by default?
- what is okay to summarize upward?
- what should happen next today?

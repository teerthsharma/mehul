# Novelpedia Team DM Onboarding System

## Goal
Create a simple, repeatable way for Novelpedia team members to DM Hermes on Discord, get lightly onboarded, and end with:
- an identifiable Discord username and profile slug
- a clean employee profile document
- curated durable memory for that employee context
- a role-appropriate SOUL draft for the employee-facing Hermes profile
- an AGENTS draft for the workspace/context docs that will hold Novelpedia-specific workflow rules
- a first-pass understanding of current work, blockers, collaborators, and support needs

This system is designed for work execution, not therapy.

## Core design rules
1. Keep onboarding short enough that people actually do it.
2. Ask simple questions first; learn the rest from live work later.
3. Use SOUL.md for identity, tone, style, and defaults.
4. Use AGENTS.md in the working directory / messaging workspace (or another supported project context file) for Novelpedia-specific workflow rules, tools, file locations, and operating instructions.
5. Do not ask employees to dump their whole life story.
6. Do not ask for secrets, passwords, API keys, or sensitive credentials in DM.
7. Treat private coaching and manager-visible execution facts as different things.
8. Sync important outputs into visible markdown artifacts rather than hiding everything in memory.

Operational notes from Hermes docs:
- `SOUL.md` is loaded from the active profile's `HERMES_HOME`.
- `AGENTS.md` is working-directory context, not a profile-home twin of `SOUL.md`. For messaging flows, point `MESSAGING_CWD` at the workspace containing the real `AGENTS.md` if you want that context loaded consistently.
- If one-profile-per-employee is implemented as simultaneous live messaging gateways, each profile needs its own bot token/process or a separate routing layer; Hermes blocks sharing one Discord/Telegram/Slack token across multiple active profiles.

## What Hermes should collect from each employee
Minimum durable facts:
- preferred name
- Discord username
- role
- main responsibilities
- current priorities
- current blockers
- recurring collaborators / dependencies
- preferred style of help from Hermes
- manager-visible vs private boundaries for normal work updates

Optional facts, only if naturally useful:
- preferred reminder style
- preferred communication style
- recurring work rhythms
- known growth areas they want help with

## Recommended onboarding flow

### Phase 0: Entry and boundaries
Purpose: establish that this is a work assistant, not a surveillance trap or therapy bot.

Hermes should say, in substance:
- I am here to help you execute better at work.
- I will ask a short set of questions to understand your role, current work, blockers, and how I can help.
- Do not send credentials, passwords, tokens, or sensitive secrets.
- Keep answers short; we can refine over time.

### Phase 1: Identity and role
Ask:
1. What should I call you?
2. What is your Discord username / handle in this server?
3. What is your role at Novelpedia?
4. What are the main things you own right now?

Outcome:
- create employee slug
- create basic employee profile draft

### Phase 2: Current work and blockers
Ask:
5. What are the top 1-3 things you are working on right now?
6. What usually blocks you or slows you down?
7. Who do you most often depend on to move faster?
8. What should I remind or nudge you about most often?

Outcome:
- current tasks section
- blocker patterns section
- dependency map seed

### Phase 3: Personalization and working style
Ask:
9. When I help you, what is most useful: prioritizing, brainstorming, follow-up drafting, breaking work down, reminding, or pressure/check-ins?
10. Do you want me to be blunt, neutral, or more supportive by default?
11. What kinds of updates are fine to summarize for founder/manager visibility, and what should stay private unless you explicitly ask?
12. What is one thing you wish people understood better about your work?

Outcome:
- SOUL personalization seed
- visibility notes
- support preference notes

### Phase 4: Immediate usefulness
Ask:
13. What is the most important thing you need to get done next?
14. What is the biggest current blocker or risk I should know about today?

Outcome:
- immediate next-action summary
- possible same-day nudge or blocker report

## What Hermes creates after each employee onboarding
For each employee, create a folder like:
`~/.hermes/onboarding/novelpedia-founder/team-members/<employee-slug>/`

Inside it create:
1. `employee-profile.md`
2. `employee-onboarding-summary.md`
3. `SOUL.draft.md`
4. `AGENTS.draft.md`

## File creation rules
- `employee-profile.md` holds the durable structured profile.
- `employee-onboarding-summary.md` holds the raw onboarding synthesis and immediate next actions.
- `SOUL.draft.md` contains identity/style guidance only and should later be copied into the actual profile `SOUL.md`.
- `AGENTS.draft.md` contains Novelpedia workflow specifics, expected outputs, and project-local rules as source material for the real workspace `AGENTS.md`.

Important runtime note:
- Hermes does not automatically load `SOUL.draft.md` or `AGENTS.draft.md`. These are planning artifacts until their approved contents are copied into the real runtime files.

## Memory rules
Save to memory only durable facts that will still matter later, such as:
- role
- recurring responsibilities
- stable preferences for how Hermes should help
- stable collaborator/dependency relationships
- durable blockers or growth needs

Do not save:
- full transcripts
- temporary emotional noise
- one-day task lists
- speculative negative judgments
- secrets

## Visibility model
Use these labels in employee-facing outputs when useful:
- [private]
- [manager-visible]
- [founder-brief-eligible]
- [ephemeral]

Default behavior:
- coaching/reflection = private
- status, blockers, asks = often manager-visible
- only serious blockers, risks, slips, and important movement should become founder-brief-eligible

## SOUL vs AGENTS for employee profiles
Use the SOUL guide correctly:

Put in SOUL:
- how the employee agent speaks
- how blunt or warm it is
- whether it pushes back
- how it handles ambiguity
- what style it avoids

Do not put in SOUL:
- where documents live
- which Discord channels are used
- exact standup formats
- project workflow steps
- internal tool paths

Put those in the real workspace `AGENTS.md` (or another supported project context file), with profile docs serving only as source material if needed.

## Suggested operating rhythm after onboarding
Once an employee is onboarded, the profile should be able to help with:
- daily standup triage
- blocker clarification
- follow-up drafting
- status summarization
- meeting-to-action extraction
- dependency handoffs
- growth/retrospective notes

## Failure modes to avoid
- making onboarding too long
- asking abstract questions people hate answering
- storing too much noisy data in memory
- mixing private context with manager-visible context carelessly
- making SOUL files bloated with project rules
- pretending the profile knows the employee deeply after one DM

## Practical rule
The onboarding should feel like: "help me help you do your work better"
Not: "confess your soul to the bot."

# Assistant Extra Questions

## Deferred until after onboarding / after access
- Understand the two main folders by reading the actual Drive, not by guessing from names.
- Identify which sheets are dashboards versus raw tracking versus pipelines after seeing real usage.
- Design the exact daily standup system after onboarding, when real execution flow is visible.
- Work out employee markdown structure after observing actual team blockages.

## Questions still worth resolving later
- What meeting cadence exists besides weekly syncs?
- What escalation behavior is acceptable when someone repeatedly does not follow through?
- Which parts of employee notes are private coaching versus manager-visible execution context?
- What exact evidence should be required before a cross-peer skill/capability inference is stored?

## Remaining unknowns to learn from observation rather than interview
1. What overload/slippage looks like for Mehul in practice.
2. Which reminder styles actually work versus get ignored.
3. Which team capabilities and complementarities are real once observed in work.
4. Which contextual signals should trigger stronger escalation.

## Resolved defaults from onboarding
1. Daily founder brief must always include: team blockers, growth movement, and urgent risks.
2. Default escalation timing for team blockers: same day.
3. Employee profile mandatory structured fields: role, strengths, current tasks, blockers, skills, reliability, growth areas, recent misses.
4. Founder reporting should include both problems/exceptions and wins/momentum.

# Hermes local docs index

Status: local Hermes docs are installed and usable.

Primary local docs root
- `~/.hermes/hermes-agent/website/docs`
- Absolute path: `/home/LENOVO/.hermes/hermes-agent/website/docs`
- Verified as the main Docusaurus docs source.
- Local count at audit time: 113 Markdown/MDX files.

Fastest high-signal entry points
- Overview / landing page:
  - `~/.hermes/hermes-agent/website/docs/index.md`
- Quick start:
  - `~/.hermes/hermes-agent/website/docs/getting-started/quickstart.md`
  - `~/.hermes/hermes-agent/website/docs/getting-started/installation.md`
- Core user docs:
  - `~/.hermes/hermes-agent/website/docs/user-guide/cli.md`
  - `~/.hermes/hermes-agent/website/docs/user-guide/configuration.md`
  - `~/.hermes/hermes-agent/website/docs/user-guide/messaging/index.md`
  - `~/.hermes/hermes-agent/website/docs/user-guide/features/tools.md`
  - `~/.hermes/hermes-agent/website/docs/user-guide/features/skills.md`
  - `~/.hermes/hermes-agent/website/docs/user-guide/features/mcp.md`
  - `~/.hermes/hermes-agent/website/docs/user-guide/features/memory.md`
  - `~/.hermes/hermes-agent/website/docs/user-guide/features/voice-mode.md`
- Reference docs:
  - `~/.hermes/hermes-agent/website/docs/reference/cli-commands.md`
  - `~/.hermes/hermes-agent/website/docs/reference/slash-commands.md`
  - `~/.hermes/hermes-agent/website/docs/reference/tools-reference.md`
  - `~/.hermes/hermes-agent/website/docs/reference/toolsets-reference.md`
  - `~/.hermes/hermes-agent/website/docs/reference/environment-variables.md`
  - `~/.hermes/hermes-agent/website/docs/reference/faq.md`
- Integrations:
  - `~/.hermes/hermes-agent/website/docs/integrations/providers.md`
  - `~/.hermes/hermes-agent/website/docs/integrations/index.md`
- Developer docs:
  - `~/.hermes/hermes-agent/website/docs/developer-guide/architecture.md`
  - `~/.hermes/hermes-agent/website/docs/developer-guide/contributing.md`
  - `~/.hermes/hermes-agent/website/docs/developer-guide/adding-tools.md`
  - `~/.hermes/hermes-agent/website/docs/developer-guide/gateway-internals.md`
  - `~/.hermes/hermes-agent/website/docs/developer-guide/agent-loop.md`

Useful non-site docs in the local repo
- Repository overview:
  - `~/.hermes/hermes-agent/README.md`
- Developer/codebase quick reference:
  - `~/.hermes/hermes-agent/AGENTS.md`
- Supplementary repo docs root:
  - `~/.hermes/hermes-agent/docs`
  - Absolute path: `/home/LENOVO/.hermes/hermes-agent/docs`
  - Local count at audit time: 5 Markdown files.
  - Not the main docs tree; mostly supplementary/internal docs.
  - Useful examples:
    - `~/.hermes/hermes-agent/docs/acp-setup.md`
    - `~/.hermes/hermes-agent/docs/migration/openclaw.md`
    - `~/.hermes/hermes-agent/docs/honcho-integration-spec.md`

Observed top-level sections under `website/docs`
- `getting-started`
- `user-guide`
- `reference`
- `integrations`
- `developer-guide`

Lookup recommendation
1. Start with `website/docs/index.md` for navigation.
2. Use `README.md` for a concise product overview.
3. Use `reference/*.md` for exact commands/options.
4. Use `AGENTS.md` and `developer-guide/*.md` for codebase internals.
5. Treat `docs/` as supplementary, not canonical end-user docs.

Cache / scraping status
- No extra scraping or offline cache install is needed right now because the main local docs tree is already present under `~/.hermes/hermes-agent/website/docs`.
